<?php

// Start the session
session_start();

// Set session variables
$_SESSION["loggedin"] = FALSE;

function jheader(){
	echo'<style>
.dropdown-submenu {
    position: relative;
}

.dropdown-submenu .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
}
</style>
    <div class="tagline-upper text-center text-heading text-shadow text-white mt-5 d-none d-lg-block">  CT Pizzas</div>
    <div class="tagline-lower text-center text-expanded text-shadow text-uppercase text-white mb-5 d-none d-lg-block"> Cape Town | South Africa | +27 74 310 4438</div>
	
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-faded py-lg-4">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="#">Enotech</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="index.php">Home
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="menu.php">Menu</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="contact.php">Contact</a>
            </li>
            <li class="nav-item px-lg-4"> 
			  <div class="dropdown">
			  <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Account
    <span class="caret"></span></button>
    <ul class="dropdown-menu">';
	  if($_SESSION["loggedin"] == TRUE){
      echo'<li><a tabindex="-1" href="manageaccount.php">Manage Acoount</a></li>
      <li><a tabindex="-1" href="logout.php">Logout</a></li>';}
	  else{
      echo'<li><a tabindex="-1" href="signup.php">Signup</a></li>
      <li><a tabindex="-1" href="#" id="log">Login</a></li>';
	  }
          echo'</ul>
  </div>
            </li>';
			
			echo'
          </ul>
        </div>
      </div>
    </nav>
	 
<script>
$(document).ready(function(){
  $(".dropdown-submenu a.test").on("click", function(e){
    $(this).next("ul").toggle();
    e.stopPropagation();
    e.preventDefault();
  });
}); 
</script>;';
}
function jfooter(){
	echo'
    <!-- /.container -->

    <footer class="bg-faded text-center py-5">
      <div class="container">
        <p class="m-0">Copyright &copy; Enotech 2017</p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>';
}
function jboot(){
	echo ' <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="vendor/bootstrap/css/bootstrap.min.js"></script>
  <style>
  .modal-header, h4, .close {
      background-color: #5cb85c;
      color:white !important;
      text-align: center;
      font-size: 30px;
  }
  .modal-footer {
      background-color: #f9f9f9;
  }
  </style>';
	}
function jmodal(){
	echo'   
<div class="container">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Login</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <form role="form" action="'.$_SERVER['PHP_SELF'].'">
            <div class="form-group">
              <label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
              <input type="text" class="form-control" id="usrname" placeholder="Enter email">
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
              <input type="text" class="form-control" id="psw" placeholder="Enter password">
            </div>
            <div class="checkbox">
              <label><input type="checkbox" value="" checked>Remember me</label>
            </div>
              <button type="submit" class="btn btn-success btn-block"><span class="glyphicon glyphicon-off"></span> Login</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
          <p>Not a member? <a href="signup.php">Sign Up</a></p>
          <p>Forgot <a href="pwdreset.php">Password?</a></p>
        </div>
      </div>
      
    </div>
  </div> 
</div>
 
<script>
$(document).ready(function(){
    $("#account").click(function(){
        $("#myModal").modal();
    });
});
$(document).ready(function(){
    $("#log").click(function(){
        $("#myModal").modal();
    });
});
</script> ';
}
function jlogin(){
	if(isset($_REQUEST['usrname'])){
$email=$_REQUEST['usrname'];
$password=$_REQUEST['psw'];

$conn=jdbcon();

$sql = "SELECT pwd FROM details WHERE email=".$email;
$result = $conn->query($sql);

if ($result->num_rows > 0) {	
    while($row = $result->fetch_assoc()) {
		if($row["lastname"]==$password)
        echo "Success!";
		$_SESSION["loggedin"] = TRUE;
    }
    } else {
		
    echo '
	<script>  
		$("#mymodal").on("hidden.bs.modal", function() {
  this.modal("show");
});
</script>;
	
	Incorrect login"';
}
$conn->close();
}}
function jdbcon(){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clients";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

return $conn;
}
?>