<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Menu</title>
    <?php require 'headers.php';
	 jboot();?>
  </head>

  <body>

<?php 
jheader();  ?> 

   <div class="container">

      <div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/slide-1.jpg" alt="">
          <div class="card-img-overlay bg-overlay">
            <h4 class="card-title text-shadow text-white text-uppercase mb-0">Vegetarian Pizza</h4>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">R99</p>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">Suitable for veggans</p>
            <a href="contact.html" class="btn btn-secondary">Order</a>
          </div>
        </div>
      </div>
      </div>


    <div class="container">
      <div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/slide-2.jpg" alt="">
          <div class="card-img-overlay bg-overlay">
            <h4 class="card-title text-shadow text-white text-uppercase mb-0">Indian Pizza</h4>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">R129</p>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">Purely nutural</p>
            <a href="contact.html" class="btn btn-secondary">Order</a>
          </div>
        </div>
      </div>

      </div>

    <div class="container">
      <div class="bg-faded p-4 my-4">
        <div class="card card-inverse">
          <img class="card-img img-fluid w-100" src="img/slide-3.jpg" alt="">
          <div class="card-img-overlay bg-overlay">
            <h4 class="card-title text-shadow text-white text-uppercase mb-0">French Cockies</h4>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">R69</p>
            <p class="lead card-text text-shadow text-white w-50 d-none d-lg-block">soft brown cockies</p>
            <a href="contact.html" class="btn btn-secondary">Order</a>
          </div>
        </div>
      </div>

      <!-- Pagination -->
      <div class="bg-faded p-4 my-4">
        <ul class="pagination justify-content-center mb-0">
          <li class="page-item"><em><strong>It's that pizza you've always liked!</strong></em></li>
        </ul>
      </div>

    </div>
 

    
<?php  
jmodal();
jfooter();  ?>
  </body>

</html>
